//Interface to be implemented by all Quadrilaterals
public interface QuadFunctions {

	public double area();

	public double perimeter();

}
