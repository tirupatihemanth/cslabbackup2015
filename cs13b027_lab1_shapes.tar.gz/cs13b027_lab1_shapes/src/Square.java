//Square class which inherits from Rectangle and implements QuadFunction interface
public class Square extends Rectangle implements QuadFunctions {

	public Square(double length) {
		super(length, length);
	}
}
