package cs13b027_lab1_2;

public class NonTeachingClassEmployee extends Employee {

	//class representing the nonTeachingEmployee class
	public void longBio() {
		style("Long Biography");
		data();
		System.out.println("\tclass: " + "Non Teaching Class");
		style();
	}

}
